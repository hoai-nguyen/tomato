import json
import os
import boto3
import uuid

s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('aws2020-01-nhom1-tomato-Orders-table')

def lambda_handler(event, context):
    print("event shipInfo: ", event)
    print("=========")
    try:
        table.update_item(
            Key={
            'OrderID': event.get('OrderID')
            },
            UpdateExpression="set DeliveryStatus = :r",
            ExpressionAttributeValues={
                ':r': event['status'],
            },
            ReturnValues="UPDATED_NEW"
        )
    except Exception as e:
        raise Exception('400' + str(e))
    

    return {
        'statusCode': 200,
        'body': "OK"
    }
