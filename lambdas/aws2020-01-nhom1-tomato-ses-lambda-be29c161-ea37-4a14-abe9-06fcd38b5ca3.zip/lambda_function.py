import boto3
import json
import os
import decimal

s3 = boto3.client('s3')
ddb = boto3.resource('dynamodb')
ses_client = boto3.client("ses")

#main mail address of Tomato Japan systems
tomato_email = "aws202001.group1.tomatosystem@gmail.com"

#------------------------Init table--------------------------------------------------------------------------------------------------
def init_table(tbname):
    return ddb.Table(tbname)

#------------------------Find in table-----------------------------------------------------------------------------------------------
def find_in_orders_table(table, field, orderID):
    response = table.scan()
    for rd in response['Items']:
        if (rd.get('OrderID')):
            id = rd['OrderID']
            if (id == orderID):
                return rd[field]
        
    return "Not Found"

def find_in_shiper_table(table, field, shiperID):
    response = table.scan()
    for rd in response['Items']:
        if (rd.get('ShipperID')):
            id = rd['ShipperID']
            if (id == shiperID):
                return rd[field]
        
    return "Not Found"

#-------------------------Check field change or not (by compare newIamge and OldImage)--------------------------------------------------        
def check_status_change(record):
    
    dynamodb = record['dynamodb']
    newStatus = {}
    oldStatus = {}
    
    if (dynamodb.get('NewImage') and dynamodb.get('OldImage')) :
        newimg = dynamodb['NewImage']
        if (newimg.get('DeliveryStatus')):
            newStatus = newimg['DeliveryStatus']['S']
        else:
            return False    #Current record has no DeliveryStatus value, then do nothing
            
        oldimg = dynamodb['OldImage']
        if (oldimg.get('DeliveryStatus')):
            oldStatus = oldimg['DeliveryStatus']['S']
        else:
            return True
    else:
        return True;
        
    if newStatus != oldStatus:
        return True
    else:
        return False
        
#--------------------------------------------------------------------------------------------------------------------------------------
def check_date_change(record):
    dynamodb = record['dynamodb']
    newStatus = {}
    oldStatus = {}
    
    if (dynamodb.get('NewImage') and dynamodb.get('OldImage')) :
        newimg = dynamodb['NewImage']
        if (newimg.get('DeliveryDateTime')):
            newStatus = newimg['DeliveryDateTime']['S']
        else:
            return False    #Current record has no DeliveryStatus value, then do nothing
            
        oldimg = dynamodb['OldImage']
        if (oldimg.get('DeliveryDateTime')):
            oldStatus = oldimg['DeliveryDateTime']['S']
        else:
            return False
    else:
        return False
        
    #Only send mail if date is changed
    if newStatus != oldStatus:
        return True
    else:
        return False
        
#--------------------------------------------------------------------------------------------------------------------------------------
def send_mail_to_shiper_shop(orderID, pickAddress, deliveryAddress, deliveryDate, shiperEmail, shopEmail):
    subject = "Emazon-Request for pick items"
    link = "http://aws2020-01-nhom1-tomato-bucket.s3-website-ap-southeast-1.amazonaws.com/shipInfo.html?OrderID=" + orderID
    body = """
        <html>
        <head></head>
        <body>
            <p>Hi Shiper,<br></p>
            
            <p>Emazon is requesting pick the following items:<br>
            <blockquote>
            OrderID             : {} <br>
            Pick Address        : {} <br>
            Delivery Address    : {} <br>
            Delivery Date       : {} <br>
            </blockquote>
            For more informations, go to <a href='{}'>This Page</a>.<br>
            Please confirm the address carefully before go to stock.<br>
            </p>
            <p>Thanks & regards,<br>
            Tomato, Japan</p>
        </body>
        </html>""".format(orderID, pickAddress, deliveryAddress, deliveryDate, link)
            
    message = {"Subject" : {"Data" : subject}, "Body": {"Html": {"Data": body}}}
    response = ses_client.send_email(Source = tomato_email, Destination = {"ToAddresses": [shiperEmail, shopEmail]}, Message = message)

#--------------------------------------------------------------------------------------------------------------------------------------
def send_mail_to_customer(orderID, customerEmail):
    subject = "Orders deliver failed (#{})".format(orderID)
    link = "http://aws2020-01-nhom1-tomato-bucket.s3-website-ap-southeast-1.amazonaws.com/re_delivery.html?OrderID=" + orderID
    body = """
        <html>
        <head></head>
        <body>
            <p>Hi Customer,<br></p>
            
            <p>We have received a request to re-delivery. Please go to
                <a href='{}'>Request Re-delivery Page</a> for more informations.
            </p>
            <p>Thanks & regards,<br>
            Tomato, Japan</p>
        </body>
        </html>""".format(link)
            
    message = {"Subject" : {"Data" : subject}, "Body": {"Html": {"Data": body}}}
    response = ses_client.send_email(Source = tomato_email, Destination = {"ToAddresses": [customerEmail]}, Message = message)

#--------------------------------------------------------------------------------------------------------------------------------------
def send_mail_to_customer_shop_picked(orderID, customerEmail, shopEmail):
    subject = "Orders has picked (#{})".format(orderID)
    body = """
        <html>
        <head></head>
        <body>
            <p>Hi Customer & Shop,<br></p>
            
            <p>We inform you that your orders has been picked.<br></p>
            <p>Thanks & regards,<br>
            Tomato, Japan</p>
        </body>
        </html>"""
            
    message = {"Subject" : {"Data" : subject}, "Body": {"Html": {"Data": body}}}
    response = ses_client.send_email(Source = tomato_email, Destination = {"ToAddresses": [customerEmail, shopEmail]}, Message = message)

#--------------------------------------------------------------------------------------------------------------------------------------
def send_mail_to_customer_shop_succeed(orderID, customerEmail, shopEmail):
    subject = "Orders has deliveried (#{})".format(orderID)
    body = """
        <html>
        <head></head>
        <body>
            <p>Hi Customer & Shop,<br></p>
            
            <p>We inform you that your order has been deliveried.<br></p>
            <p>Thanks & regards,<br>
            Tomato, Japan</p>
        </body>
        </html>"""
            
    message = {"Subject" : {"Data" : subject}, "Body": {"Html": {"Data": body}}}
    response = ses_client.send_email(Source = tomato_email, Destination = {"ToAddresses": [customerEmail, shopEmail]}, Message = message)
    

#--------------------------------------------------------------------------------------------------------------------------------------
def send_email_all(orderID, customerEmail, shopEmail, shiperEmail):
    subject = "Orders has returned (#{})".format(orderID)
    body = """
        <html>
        <head></head>
        <body>
            <p>Hi Customer & Shop & Shiper,<br></p>
            
            <p>We inform you that your order has returned to stock.<br></p>
            <p>Thanks & regards,<br>
            Tomato, Japan</p>
        </body>
        </html>"""
            
    message = {"Subject" : {"Data" : subject}, "Body": {"Html": {"Data": body}}}
    response = ses_client.send_email(Source = tomato_email, Destination = {"ToAddresses": [customerEmail, shopEmail, shiperEmail]}, Message = message)

#--------------------------------------------------------------------------------------------------------------------------------------
def send_mail_to_shiper_customer(orderID, deliveryAddress, deliveryDate, shiperEmail, customerEmail):
    subject = "Request for re-delivery (#{})".format(orderID)
    link = "http://aws2020-01-nhom1-tomato-bucket.s3-website-ap-southeast-1.amazonaws.com/shipInfo.html?OrderID=" + orderID
    body = """
        <html>
        <head></head>
        <body>
            <p>Hi Shiper & Customer,<br></p>
            
            <p>We inform that customer has requested to re-delivery the following orders:<br></p>
            <blockquote>
            OrderID             : {} <br>
            Delivery Address    : {} <br>
            Delivery Date       : {} <br>
            </blockquote>
            
            <p>Visit <a href='{}'>This Page</a> to update status of orders.<br><br></p>
            <p>Thanks & regards,<br>
            Tomato, Japan</p>
        </body>
        </html>""".format(orderID, deliveryAddress, deliveryDate, link)
            
    message = {"Subject" : {"Data" : subject}, "Body": {"Html": {"Data": body}}}
    response = ses_client.send_email(Source = tomato_email, Destination = {"ToAddresses": [shiperEmail, customerEmail]}, Message = message)
    
    
#------------------------------------------------------------------------------------------------------------------------------------------
def get_order_id(record):
    dynamodb = record['dynamodb']
    keys = {}
    
    if (dynamodb.get('Keys')):
        keys = dynamodb['Keys']
        if (keys.get('OrderID')):
            return keys['OrderID']['S']
            
    return "Not Found"

#-------------------------Main handler (for send mail based on status)----------------------------------------------------------------------        
def verify_record_to_send_mail(ordersTable, shiperTable, record):
    #First, check item status is change or not
    statusCheck = check_status_change(record)
    dateCheck = False
    
    #Delivery status is no change/no exist, continue to check date
    if (statusCheck == False):
        
        #Check Receive date (for re-delivery request)
        dateCheck = check_date_change(record)
        if (dateCheck == False):
            return {
                "statusCode" : 200,
                "body" : "Nothing changed"
            }

    #Note : If both delivery status and date is changed, delivery status is priority

    
    #Get OrderID from changed record
    orderID = get_order_id(record)
    if (orderID == "Not Found"):
        return {
            "statusCode" : 200,
            "Body" : "OrderID not found"
        }
    
    #Based on OrderID, get others informations
    #Orders table
    itemStatus = find_in_orders_table(ordersTable, 'DeliveryStatus', orderID).lower()
    customerEmail = find_in_orders_table(ordersTable, 'CustomerEmail', orderID)
    shopEmail = find_in_orders_table(ordersTable, 'ShopEmail', orderID)
    
    #Shipper table
    shiperID = find_in_orders_table(ordersTable, 'ShipperID', orderID)
    shiperEmail = find_in_shiper_table(shiperTable, 'Email', shiperID)

    #Make sure data is valid
    if (itemStatus == "Not Found" and
        customerEmail == "Not Found" and
        shopEmail == "Not Found" and
        shiperID == "Not Found" and
        shiperEmail == "Not Found"):
        return {
            "statusCode" : 200,
            "body" : "Not Found"
        }
    
    #Get detail of order
    pickAddress = find_in_orders_table(ordersTable, 'PickItemAddress', orderID)
    deliveryAddress = find_in_orders_table(ordersTable, 'DeliveryAddress', orderID)
    deliveryDate = find_in_orders_table(ordersTable, 'DeliveryDateTime', orderID)
    
    #If only deliveryDate is changed, just send mail and return (It mean customer is request re-delivery)
    if (dateCheck == True):
        send_mail_to_shiper_customer(orderID, deliveryAddress, deliveryDate, shiperEmail, customerEmail)
        
        return {
            "statusCode" : 200,
            "Body" : "Customer request re-delivery, mail is OK"
        }
    
    #Check status and send email
    #If status is New, just mail to shiper and shop
    if (itemStatus == 'new'):
        send_mail_to_shiper_shop(orderID, pickAddress, deliveryAddress, deliveryDate, shiperEmail, shopEmail)
        
    #If status is Picked, just mail to customer and shop
    elif (itemStatus == 'picked'):
        send_mail_to_customer_shop_picked(orderID, customerEmail, shopEmail)
         
    #If status is Succeed, just mail to customer and shop
    elif (itemStatus == 'succeed'):
        send_mail_to_customer_shop_succeed(orderID, customerEmail, shopEmail)
         
    #If status is Failed, just mail to customer, them customer make re-delivery request
    elif (itemStatus == 'failed'):
        send_mail_to_customer(orderID, customerEmail)
         
    #If status is Returned, just mail to shop and customer and shiper
    elif (itemStatus == 'return'):
        send_email_all(orderID, customerEmail, shopEmail, shiperEmail)
    
    return {
        "ErrorCode" : 200,
        "ItemStatus" : itemStatus,
        "CustomerEmail" : customerEmail,
        "ShopEmail" : shopEmail
    }
    
#--------------------------------------------------------------------------------------------------------------------------------------
#Main function
def lambda_handler(event, context):
    
    #For test,
    #s3.put_object(Bucket='aws2020-01-nhom1-tomato-bucket',
    #Key='checkfile.json',
    #Body=json.dumps(event),
    #ContentType='application/json')
    
    
    #Create Orders table
    ordersTable = init_table("aws2020-01-nhom1-tomato-Orders-table")
    
    #Create Shiper table
    shiperTable = init_table("aws2020-01-nhom1-tomato-Shipper-Table")
    
    #When event comming from DynamoDB Streams, loop all records
    for record in event['Records']:
        verify_record_to_send_mail(ordersTable, shiperTable, record)
        
        
    return {
        'statusCode': 200,
        'body': json.dumps('Everything is work perfectly!!!')
    }
#--------------------------------------------------------------------------------------------------------------------------------------