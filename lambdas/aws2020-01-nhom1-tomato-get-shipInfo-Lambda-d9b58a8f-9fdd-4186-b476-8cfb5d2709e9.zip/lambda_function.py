import json
import boto3


dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('aws2020-01-nhom1-tomato-Orders-table')

def lambda_handler(event, context):
    print("event get shipInfo: ", event)
    print("table:", table)
    print("=========")
    
    response = {}
    try:
        order_id = event.get('OrderID')
        response = table.get_item(Key={'OrderID': order_id})
    except Exception as e:
        raise Exception('500')
        
    if not response.get('Item'):
        raise Exception('400')

    return {
        'statusCode': 200,
        'body': json.dumps(response.get('Item'))
    }
